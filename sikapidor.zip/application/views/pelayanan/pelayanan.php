<!-- ======= Tentang Program ======= -->
<section id="team" class="team section-bg mt-5">
	<div class="container" data-aos="fade-up">

		<div class="section-title">
			<h2>Tentang Program</h2>
			<p>Pilihlah Dekorasi yang sesuai kamu suka, karena pilahanmu saat ini adalah impianmu di saat acara nanti</p>
		</div>

		<div class="row">

			<div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
					<div class="member-info">
						<h4>BISNIS DIGITAL</h4>
						<span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis facilis quos, id rem et quisquam natus nihil! Expedita, consequatur molestiae ab accusantium porro, dolores maiores recusandae numquam velit molestias sequi?</span>
						<p><strong>Profil</strong></p>
						<span>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae eius vel architecto dicta sint voluptatibus ipsa neque maxime excepturi reprehenderit fugit deserunt, ab nesciunt. Nostrum, consequatur? Inventore mollitia ducimus voluptate!</span>
					</div>
				</div>
			</div>

			<div class="col-lg-6">
				<div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
					<div class="member-info">
						<h4>BISNIS DIGITAL</h4>
						<span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Non inventore vero repellat odit, voluptas voluptatem similique omnis at cupiditate nam quibusdam cumque perferendis ipsam sapiente voluptates nostrum incidunt! Eum, sunt.</span>
						<p><strong>Profil</strong></p>
						<span>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolorum iste eum officiis! Quisquam, nostrum eos, minima blanditiis, recusandae libero explicabo illo repellat nisi labore commodi quae ratione fugit harum aliquam.</span>
					</div>
				</div>
			</div>

		</div>
	</div>
</section><!-- End Team Section -->
